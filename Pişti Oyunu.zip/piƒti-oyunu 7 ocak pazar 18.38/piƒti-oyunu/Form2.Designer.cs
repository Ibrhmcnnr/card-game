﻿namespace pişti_oyunu
{
    partial class PiştiOyunu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PiştiOyunu));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.Kart6 = new System.Windows.Forms.PictureBox();
            this.Kart7 = new System.Windows.Forms.PictureBox();
            this.Kart8 = new System.Windows.Forms.PictureBox();
            this.Kart1 = new System.Windows.Forms.PictureBox();
            this.Kart2 = new System.Windows.Forms.PictureBox();
            this.Kart3 = new System.Windows.Forms.PictureBox();
            this.Kart4 = new System.Windows.Forms.PictureBox();
            this.btnDagıt = new System.Windows.Forms.Button();
            this.Kart9 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.Kart5 = new System.Windows.Forms.PictureBox();
            this.btnOyuncu1 = new System.Windows.Forms.Button();
            this.btnOyuncu2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Kart6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart9)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "karo 1.png");
            this.imageList1.Images.SetKeyName(1, "karo 2.png");
            this.imageList1.Images.SetKeyName(2, "karo 3.png");
            this.imageList1.Images.SetKeyName(3, "karo 4.png");
            this.imageList1.Images.SetKeyName(4, "karo 5.png");
            this.imageList1.Images.SetKeyName(5, "karo 6.png");
            this.imageList1.Images.SetKeyName(6, "karo 7.png");
            this.imageList1.Images.SetKeyName(7, "karo 8.png");
            this.imageList1.Images.SetKeyName(8, "karo 9.png");
            this.imageList1.Images.SetKeyName(9, "karo kızı.png");
            this.imageList1.Images.SetKeyName(10, "karo papaz.png");
            this.imageList1.Images.SetKeyName(11, "karo valesi.png");
            this.imageList1.Images.SetKeyName(12, "karo10.png");
            this.imageList1.Images.SetKeyName(13, "kupa  kızı.png");
            this.imageList1.Images.SetKeyName(14, "kupa 1.png");
            this.imageList1.Images.SetKeyName(15, "kupa 2.png");
            this.imageList1.Images.SetKeyName(16, "kupa 3.png");
            this.imageList1.Images.SetKeyName(17, "kupa 4.png");
            this.imageList1.Images.SetKeyName(18, "kupa 5.png");
            this.imageList1.Images.SetKeyName(19, "kupa 6.png");
            this.imageList1.Images.SetKeyName(20, "kupa 7.png");
            this.imageList1.Images.SetKeyName(21, "kupa 8.png");
            this.imageList1.Images.SetKeyName(22, "kupa 9.png");
            this.imageList1.Images.SetKeyName(23, "kupa 10.png");
            this.imageList1.Images.SetKeyName(24, "kupa papaz.png");
            this.imageList1.Images.SetKeyName(25, "kupa vale.png");
            this.imageList1.Images.SetKeyName(26, "maça 1.png");
            this.imageList1.Images.SetKeyName(27, "maça 2.png");
            this.imageList1.Images.SetKeyName(28, "maça 3.png");
            this.imageList1.Images.SetKeyName(29, "maça 4.png");
            this.imageList1.Images.SetKeyName(30, "maça 5.png");
            this.imageList1.Images.SetKeyName(31, "maça 6.png");
            this.imageList1.Images.SetKeyName(32, "maça 7.png");
            this.imageList1.Images.SetKeyName(33, "maça 8.png");
            this.imageList1.Images.SetKeyName(34, "maça 9.png");
            this.imageList1.Images.SetKeyName(35, "maça 10.png");
            this.imageList1.Images.SetKeyName(36, "maça kızı.png");
            this.imageList1.Images.SetKeyName(37, "maça papaz.png");
            this.imageList1.Images.SetKeyName(38, "maça vale.png");
            this.imageList1.Images.SetKeyName(39, "Sinek 1.png");
            this.imageList1.Images.SetKeyName(40, "Sinek 2.png");
            this.imageList1.Images.SetKeyName(41, "Sinek 3.png");
            this.imageList1.Images.SetKeyName(42, "Sinek 4.png");
            this.imageList1.Images.SetKeyName(43, "Sinek 5.png");
            this.imageList1.Images.SetKeyName(44, "Sinek 6.png");
            this.imageList1.Images.SetKeyName(45, "Sinek 7.png");
            this.imageList1.Images.SetKeyName(46, "Sinek 8.png");
            this.imageList1.Images.SetKeyName(47, "Sinek 9.png");
            this.imageList1.Images.SetKeyName(48, "Sinek 10.png");
            this.imageList1.Images.SetKeyName(49, "Sinek kızı.png");
            this.imageList1.Images.SetKeyName(50, "Sinek papaz.png");
            this.imageList1.Images.SetKeyName(51, "Sinek vale.png");
            // 
            // Kart6
            // 
            this.Kart6.Location = new System.Drawing.Point(516, 560);
            this.Kart6.Name = "Kart6";
            this.Kart6.Size = new System.Drawing.Size(89, 122);
            this.Kart6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart6.TabIndex = 8;
            this.Kart6.TabStop = false;
            this.Kart6.Click += new System.EventHandler(this.Kart6_Click);
            // 
            // Kart7
            // 
            this.Kart7.Location = new System.Drawing.Point(623, 560);
            this.Kart7.Name = "Kart7";
            this.Kart7.Size = new System.Drawing.Size(89, 122);
            this.Kart7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart7.TabIndex = 9;
            this.Kart7.TabStop = false;
            this.Kart7.Click += new System.EventHandler(this.Kart7_Click);
            // 
            // Kart8
            // 
            this.Kart8.Location = new System.Drawing.Point(727, 560);
            this.Kart8.Name = "Kart8";
            this.Kart8.Size = new System.Drawing.Size(89, 122);
            this.Kart8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart8.TabIndex = 10;
            this.Kart8.TabStop = false;
            this.Kart8.Click += new System.EventHandler(this.Kart8_Click);
            // 
            // Kart1
            // 
            this.Kart1.Location = new System.Drawing.Point(393, 12);
            this.Kart1.Name = "Kart1";
            this.Kart1.Size = new System.Drawing.Size(86, 118);
            this.Kart1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart1.TabIndex = 12;
            this.Kart1.TabStop = false;
            this.Kart1.Click += new System.EventHandler(this.Kart1_Click);
            // 
            // Kart2
            // 
            this.Kart2.Location = new System.Drawing.Point(501, 12);
            this.Kart2.Name = "Kart2";
            this.Kart2.Size = new System.Drawing.Size(86, 118);
            this.Kart2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart2.TabIndex = 13;
            this.Kart2.TabStop = false;
            this.Kart2.Click += new System.EventHandler(this.Kart2_Click);
            // 
            // Kart3
            // 
            this.Kart3.Location = new System.Drawing.Point(603, 12);
            this.Kart3.Name = "Kart3";
            this.Kart3.Size = new System.Drawing.Size(86, 118);
            this.Kart3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart3.TabIndex = 14;
            this.Kart3.TabStop = false;
            this.Kart3.Click += new System.EventHandler(this.Kart3_Click);
            // 
            // Kart4
            // 
            this.Kart4.Location = new System.Drawing.Point(703, 12);
            this.Kart4.Name = "Kart4";
            this.Kart4.Size = new System.Drawing.Size(86, 118);
            this.Kart4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart4.TabIndex = 15;
            this.Kart4.TabStop = false;
            this.Kart4.Click += new System.EventHandler(this.Kart4_Click);
            // 
            // btnDagıt
            // 
            this.btnDagıt.Location = new System.Drawing.Point(380, 328);
            this.btnDagıt.Name = "btnDagıt";
            this.btnDagıt.Size = new System.Drawing.Size(99, 33);
            this.btnDagıt.TabIndex = 16;
            this.btnDagıt.Text = "Kartı dağıt";
            this.btnDagıt.UseVisualStyleBackColor = true;
            this.btnDagıt.Click += new System.EventHandler(this.btnDagıt_Click);
            // 
            // Kart9
            // 
            this.Kart9.Location = new System.Drawing.Point(580, 290);
            this.Kart9.Name = "Kart9";
            this.Kart9.Size = new System.Drawing.Size(86, 118);
            this.Kart9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart9.TabIndex = 18;
            this.Kart9.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Location = new System.Drawing.Point(41, 217);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(179, 174);
            this.panel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(53, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Kalan:43";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::pişti_oyunu.Properties.Resources.kart_arka_plan;
            this.pictureBox6.Location = new System.Drawing.Point(47, 26);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(86, 118);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "";
            // 
            // Kart5
            // 
            this.Kart5.Location = new System.Drawing.Point(411, 560);
            this.Kart5.Name = "Kart5";
            this.Kart5.Size = new System.Drawing.Size(89, 122);
            this.Kart5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Kart5.TabIndex = 20;
            this.Kart5.TabStop = false;
            this.Kart5.Click += new System.EventHandler(this.Kart5_Click);
            // 
            // btnOyuncu1
            // 
            this.btnOyuncu1.Location = new System.Drawing.Point(41, 419);
            this.btnOyuncu1.Name = "btnOyuncu1";
            this.btnOyuncu1.Size = new System.Drawing.Size(73, 33);
            this.btnOyuncu1.TabIndex = 21;
            this.btnOyuncu1.Text = "Oyuncu1";
            this.btnOyuncu1.UseVisualStyleBackColor = true;
            this.btnOyuncu1.Click += new System.EventHandler(this.btnOyuncu1_Click);
            // 
            // btnOyuncu2
            // 
            this.btnOyuncu2.Location = new System.Drawing.Point(120, 419);
            this.btnOyuncu2.Name = "btnOyuncu2";
            this.btnOyuncu2.Size = new System.Drawing.Size(72, 33);
            this.btnOyuncu2.TabIndex = 22;
            this.btnOyuncu2.Text = "Oyuncu2";
            this.btnOyuncu2.UseVisualStyleBackColor = true;
            this.btnOyuncu2.Click += new System.EventHandler(this.btnOyuncu2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(325, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Oyuncu 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(343, 651);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Oyuncu 1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::pişti_oyunu.Properties.Resources.kart_arka_plan;
            this.pictureBox1.Location = new System.Drawing.Point(516, 290);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "";
            // 
            // PiştiOyunu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1173, 730);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnOyuncu2);
            this.Controls.Add(this.btnOyuncu1);
            this.Controls.Add(this.Kart5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Kart9);
            this.Controls.Add(this.btnDagıt);
            this.Controls.Add(this.Kart4);
            this.Controls.Add(this.Kart3);
            this.Controls.Add(this.Kart2);
            this.Controls.Add(this.Kart1);
            this.Controls.Add(this.Kart8);
            this.Controls.Add(this.Kart7);
            this.Controls.Add(this.Kart6);
            this.DoubleBuffered = true;
            this.Name = "PiştiOyunu";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.PiştiOyunu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Kart6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart9)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kart5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox Kart6;
        private System.Windows.Forms.PictureBox Kart7;
        private System.Windows.Forms.PictureBox Kart8;
        private System.Windows.Forms.PictureBox Kart1;
        private System.Windows.Forms.PictureBox Kart2;
        private System.Windows.Forms.PictureBox Kart3;
        private System.Windows.Forms.PictureBox Kart4;
        private System.Windows.Forms.Button btnDagıt;
        private System.Windows.Forms.PictureBox Kart9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Kart5;
        private System.Windows.Forms.Button btnOyuncu1;
        private System.Windows.Forms.Button btnOyuncu2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}