﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace pişti_oyunu
{
    public partial class PiştiOyunu : Form
    {

        private Random rnd = new Random();
        private Random rnd1 = new Random();
        private Random rnd2 = new Random();

        string[] ImagePath;

        private List<Image> imageList = new List<Image>();

        public PiştiOyunu()
        {
            InitializeComponent();

            // Resimleri listeye ekleme
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 1.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 2.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 3.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 4.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 5.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 6.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 7.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 8.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo 9.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo10.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo kızı.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo papaz.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\karo valesi.png"));

            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 1.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 2.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 3.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 4.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 5.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 6.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 7.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 8.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 9.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa 10.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\kupa papaz.png"));

            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 1.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 2.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 3.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 4.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 5.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 6.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 7.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 8.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 9.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça 10.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça kızı.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\maça papaz.png"));

            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 1.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 2.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 3.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 4.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 5.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 6.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 7.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 8.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 9.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek 10.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek kızı.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek papaz.png"));
            imageList.Add(Image.FromFile("..\\..\\Resources\\Sinek vale.png"));

            Kart1.Visible = false;
            Kart2.Visible = false;
            Kart3.Visible = false;
            Kart4.Visible = false;
            Kart5.Visible = false;
            Kart6.Visible = false;
            Kart7.Visible = false;
            Kart8.Visible = false;
            Kart9.Visible = false;
        }





        // Diğer buton click olayları için benzer şekilde ImagePath kontrolü eklenebilir.



        private void btnDagıt_Click(object sender, EventArgs e)
        {

            Kart1.Enabled = false;
            Kart2.Enabled = false;
            Kart3.Enabled = false;
            Kart4.Enabled = false;
            Kart5.Enabled = false;
            Kart6.Enabled = false;
            Kart7.Enabled = false;
            Kart8.Enabled = false;
            Kart9.Enabled = false;

            Kart1.Visible = true;
            Kart2.Visible = true;
            Kart3.Visible = true;
            Kart4.Visible = true;
            Kart5.Visible = true;
            Kart6.Visible = true;
            Kart7.Visible = true;
            Kart8.Visible = true;
            Kart9.Visible = true;
            if (imageList.Count > 0)
            {
                List<int> usedIndexes = new List<int>(); // Kullanılan indisleri saklamak için liste

                foreach (Control control in Controls) // Form üzerindeki tüm kontrol elemanlarını döngü ile gez
                {
                    if (control is PictureBox pictureBox)
                    {
                        int randomIndex;
                        do
                        {
                            randomIndex = rnd.Next(0, imageList.Count); // Rastgele bir indis seç

                        } while (usedIndexes.Contains(randomIndex)); // Daha önce kullanılmış bir indis ise tekrar seç

                        pictureBox.Image = imageList[randomIndex]; // PictureBox'a resmi ata
                        usedIndexes.Add(randomIndex); // Kullanılan indisleri listeye ekle
                    }
                }
            }
            else
            {
                MessageBox.Show("Resim bulunamadı.");
            }
        }

        private void Kart1_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart1.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
            Kart2.Enabled = false;
            Kart3.Enabled = false;
            Kart4.Enabled = false;
        }

        // İki resmin aynı kategoriye ait olup olmadığını kontrol eden yardımcı bir metot
        private bool SameCategory(Image img1, Image img2)
        {
            string img1FileName = Path.GetFileNameWithoutExtension(img1.ToString());
            string img2FileName = Path.GetFileNameWithoutExtension(img2.ToString());

            string[] img1Split = img1FileName.Split(' ');
            string[] img2Split = img2FileName.Split(' ');

            string img1Category = img1Split.Length > 1 ? img1Split[1] : ""; // İkinci kısmı al
            string img2Category = img2Split.Length > 1 ? img2Split[1] : ""; // İkinci kısmı al

            return img1Category == img2Category;
        }

        private void Kart2_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart2.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void Kart3_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart3.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void Kart4_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart4.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void Kart5_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart5.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void Kart6_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart6.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void Kart7_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart7.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void Kart8_Click(object sender, EventArgs e)
        {
            PictureBox clickedPictureBox = sender as PictureBox;

            if (clickedPictureBox != null)
            {
                // Kart 9'un resmi ile aynı türde bir resim ise
                if (Kart9.Image != null && SameCategory(clickedPictureBox.Image, Kart9.Image))
                {
                    clickedPictureBox.Visible = false; // Kartın görünürlüğünü kaldır
                    Kart9.Image = Kart8.Image;
                }
                else
                {
                    clickedPictureBox.Visible = false;
                    Kart9.Image = clickedPictureBox.Image;
                }
            }
        }

        private void PiştiOyunu_Load(object sender, EventArgs e)
        {
            
        }

        private void btnOyuncu1_Click(object sender, EventArgs e)
        {
            Kart1.Enabled=true;
            Kart2.Enabled=true;
            Kart3.Enabled=true;
            Kart4.Enabled=true;
            Kart5.Enabled=false;
            Kart6.Enabled=false;
            Kart7.Enabled=false;
            Kart8.Enabled=false;
        }

        private void btnOyuncu2_Click(object sender, EventArgs e)
        {
            Kart1.Enabled = false;
            Kart2.Enabled = false;
            Kart3.Enabled = false;
            Kart4.Enabled = false;
            Kart5.Enabled = true;
            Kart6.Enabled = true;
            Kart7.Enabled = true;
            Kart8.Enabled = true;

        }
    }
}
